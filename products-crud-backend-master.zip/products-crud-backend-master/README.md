# products-crud-backend

Pour connecter votre base de donnée:

- Créer un fichier .env
- Ajouter une variable MONGO_URI=votre-uri-mongodb

- Pour récupérer la liste des produits : GET: URL/products
- Pour récupérer un produit spécifique avec un id: GET: URL/products/:id
- Pour ajouter un produit à la liste des produits: POST: URL/products
